# Définissez l'unité d'organisation (OU) où les utilisateurs seront déposer
$OUEnd = "OU=Fin ,OU=nomdossier ,DC=com, DC=local"

# Définir la période d'inactivité (exemple 90 jours)
$daysInactive = 90
$timeSpan = (Get-Date).AddDays(-$daysInactive)

# Recherchez les utilisateurs
$users = Get-ADUser -Filter {LastLogonDate -lt $timeSpan} -Properties LastLogonDate

# Déplacez chaque utilisateur vers le nouvel OU (OUEnd)
foreach ($user in $users) {
    Move-ADObject -Identity $user.DistinguishedName -TargetPath $OUEnd
    Write-Host "$($user.Name) a été déplacé vers $OUEnd."
} 
